from django.shortcuts import render
from timetableapp.models import RegistrationModel, TimeTable
from django.db.models import Q
from django.contrib import messages
from django.shortcuts import redirect

# Create your views here.


def registration(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        registration = RegistrationModel()
        registration.name = name
        registration.username = username
        registration.password = password
        registration.save()
        return render(request,'timetable/Registration.html')
    return render(request, 'timetable/Registration.html')

def login(request):
    if request.method == 'POST':
      username = request.POST.get('username')
      password = request.POST.get('password')
      if RegistrationModel.objects.filter(Q(username=username) & Q(password=password)).exists():
          user_id =RegistrationModel.objects.get(username=username).id
          print(user_id)
          return redirect('timetable', user=user_id)
      else:
        return render(request, 'timetable/Login.html',{'error':'invalid user!'})
    return render(request, 'timetable/Login.html',{'block':'block'})



def timetable_view(request,user):
    user = RegistrationModel.objects.get(id=user).username
    if request.method == 'POST':
        timetable = TimeTable()
        day = request.POST.get('Monday')
        timetable.MONDAY08 = request.POST.get('MONDAY08:30-09:30')
        timetable.MONDAY09 = request.POST.get('MONDAY09:30-10:30')
        timetable.MONDAY10 = request.POST.get('MONDAY10:30-11:30')
        timetable.MONDAY11 = request.POST.get('MONDAY11:30-12:30')
        timetable.MONDAY02 = request.POST.get('MONDAY02:00-03:00')
        timetable.MONDAY03 = request.POST.get('MONDAY03:00-04:00')
        timetable.MONDAY04 = request.POST.get('MONDAY04:00-05:00')
        timetable.sav() 
    return render(request, 'timetable/timetable.html',{'user': user})



