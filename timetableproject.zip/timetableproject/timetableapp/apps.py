from django.apps import AppConfig


class TimetableappConfig(AppConfig):
    name = 'timetableapp'
