from django.db import models

# Create your models here.

class RegistrationModel(models.Model):
    name = models.CharField(max_length=15)
    username = models.CharField(max_length=15)
    password = models.CharField(max_length=25)


TIME_SLOT = (
    ('08:30 - 09:30', '08:30 - 09:30'),
    ('09:30 - 10:30', '09:30 - 10:30'),
    ('10:30 - 11:30', '10:30 - 11:30'),
    ('11:30 - 12:30', '11:30 - 12:30'),
    ('12:30 - 02:00', '12:30 - 02:00'),
    ('02:00- 03:00', '02:00- 03:00'),
    ('03:00 - 04:00', '03:00 - 04:00'),
    ('04:00 - 05:00', '04:00 - 05:00'),
)


DAYS_OF_WEEK = (
    ('Monday', 'Monday'),
    ('Tuesday', 'Tuesday'),
    ('Wednesday', 'Wednesday'),
    ('Thursday', 'Thursday'),
    ('Friday', 'Friday'),
    ('Saturday', 'Saturday'),
)

SUBJECT = (
    ('SUB1', 'SUB1'),
    ('SUB2', 'SUB2'),
    ('SUB3', 'SUB3'),
    ('SUB4', 'SUB4'),
    ('SUB5', 'SUB5'),
    ('library', 'library'),
    ('counselling class', 'counselling class'),
    ('seminar', 'seminar')
)



class TimeTable(models.Model):
    user = models.ForeignKey(RegistrationModel, on_delete=models.CASCADE)
    timeslot = models.CharField(
        max_length=30, choices=TIME_SLOT, default='Male')
    day = models.CharField(
        max_length=30, choices=DAYS_OF_WEEK, default='Male')
    subject = models.CharField(
        max_length=30, choices=SUBJECT, default='Male')
